package questao01;

public class ContaCorrente extends ContaBancaria{
    private double limiteChequeEspecial;
    
    public ContaCorrente(String numeroConta, double saldo, double limiteChequeEspecial) {
        super(numeroConta, saldo);
        this.limiteChequeEspecial=100;
    }
    
    @Override
    public void depositar(double valor){
         if(valor >0){
            valor=valor;
        }    
    }
    
    public void sacar(double valor){
        if(valor>limiteChequeEspecial){
            System.out.println("");
        }
    }
    
    public double getLimite(){
        return limiteChequeEspecial;
    }
    
}
