package questao01;

public class ContaBancaria {
    private String numeroConta;
    private double saldo;
    
    public ContaBancaria(String numeroConta, double saldo){
        this.numeroConta=numeroConta;
        this.saldo=0;
    }
    
    public void depositar(double valor){
        if(saldo <0){
            this.saldo=valor;
        }    
    } 
    
    public double getSaldo(){
        return saldo;
    }
    
    public String getNumeroConta(){
        return numeroConta;
    }
}
