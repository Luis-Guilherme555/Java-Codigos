import java.util.ArrayList;
import java.util.List;

public class TesteVeiculos {
    public static void main(String[] args) {
        List<Veiculo> veiculos = new ArrayList<>();
        veiculos.add(new Carro());
        veiculos.add(new Bicicleta());
        veiculos.add(new Carro());

        for (Veiculo veiculo : veiculos) {
            veiculo.acelerar();
            veiculo.frear();
            System.out.println("---");
        }
    }
}
