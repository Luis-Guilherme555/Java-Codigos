// Carro.java
public class Carro extends Veiculo {
    @Override
    public void acelerar() {
        System.out.println("Carro acelerando com motor");
    }

    @Override
    public void frear() {
        System.out.println("Carro freando com disco");
    }
}
