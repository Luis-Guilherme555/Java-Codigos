// Bicicleta.java
public class Bicicleta extends Veiculo {
    @Override
    public void acelerar() {
        System.out.println("Bicicleta acelerando com pedal");
    }

    @Override
    public void frear() {
        System.out.println("Bicicleta freando com aro");
    }
}
