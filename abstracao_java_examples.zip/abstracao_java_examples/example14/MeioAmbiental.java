public interface MeioAmbiental {
    double emissaoCO2();
}
