public class Onibus extends Transporte implements MeioAmbiental {
    @Override
    public double calcularTarifa() {
        return 4.50;
    }

    @Override
    public double emissaoCO2() {
        return 50.0; // gramas por km
    }
}
