import java.util.ArrayList;
import java.util.List;

public class TesteTransporte {
    public static void main(String[] args) {
        List<Transporte> transportes = new ArrayList<>();
        transportes.add(new Onibus());
        transportes.add(new Metro());
        transportes.add(new BicicletaCompartilhada());

        for (Transporte transporte : transportes) {
            System.out.println("Tarifa: R$" + transporte.calcularTarifa());

            if (transporte instanceof MeioAmbiental) {
                MeioAmbiental ambiental = (MeioAmbiental) transporte;
                System.out.println("Emissão CO2: " + ambiental.emissaoCO2() + "g/km");
            } else {
                System.out.println("Transporte limpo - sem emissão de CO2");
            }
            System.out.println("---");
        }
    }
}
