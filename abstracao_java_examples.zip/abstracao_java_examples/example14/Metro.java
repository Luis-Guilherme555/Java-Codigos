public class Metro extends Transporte implements MeioAmbiental {
    @Override
    public double calcularTarifa() {
        return 5.00;
    }

    @Override
    public double emissaoCO2() {
        return 10.0; // gramas por km
    }
}
