public class BicicletaCompartilhada extends Transporte {
    @Override
    public double calcularTarifa() {
        return 2.00;
    }
    // Não implementa MeioAmbiental - não emite CO2
}
