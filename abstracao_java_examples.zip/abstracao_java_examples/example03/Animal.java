public abstract class Animal {
    public abstract void emitirSom();

    // Método concreto - herdado por todas as subclasses
    public void dormir() {
        System.out.println("Zzzzz...");
    }
}
