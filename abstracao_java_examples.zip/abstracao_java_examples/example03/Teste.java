public class Teste {
    public static void main(String[] args) {
        Cachorro cachorro = new Cachorro();
        Gato gato = new Gato();

        cachorro.dormir(); // Zzzzz...
        gato.dormir();     // Zzzzz...
    }
}
