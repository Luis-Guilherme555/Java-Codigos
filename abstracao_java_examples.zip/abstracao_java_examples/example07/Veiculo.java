public abstract class Veiculo {
    protected int velocidade;

    public Veiculo() {
        this.velocidade = 0;
    }

    public abstract void acelerar();
    public abstract void frear();

    public int getVelocidade() {
        return velocidade;
    }
}
