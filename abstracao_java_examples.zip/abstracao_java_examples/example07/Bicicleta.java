public class Bicicleta extends Veiculo {
    @Override
    public void acelerar() {
        velocidade += 5;
        System.out.println("Bicicleta acelerou para " + velocidade + " km/h");
    }

    @Override
    public void frear() {
        velocidade -= 3;
        if (velocidade < 0) velocidade = 0;
        System.out.println("Bicicleta freou para " + velocidade + " km/h");
    }
}
