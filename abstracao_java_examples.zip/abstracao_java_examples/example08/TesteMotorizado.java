import java.util.ArrayList;
import java.util.List;

public class TesteMotorizado {
    public static void main(String[] args) {
        List<Veiculo> veiculos = new ArrayList<>();
        veiculos.add(new Carro());
        veiculos.add(new Bicicleta());

        for (Veiculo veiculo : veiculos) {
            veiculo.acelerar();

            // Verifica se o veículo é motorizado
            if (veiculo instanceof Motorizado) {
                Motorizado motorizado = (Motorizado) veiculo;
                motorizado.abastecer();
            }
            System.out.println("---");
        }
    }
}
