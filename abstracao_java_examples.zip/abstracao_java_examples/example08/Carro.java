public class Carro extends Veiculo implements Motorizado {
    @Override
    public void acelerar() {
        velocidade += 20;
        System.out.println("Carro acelerou para " + velocidade + " km/h");
    }

    @Override
    public void frear() {
        velocidade -= 15;
        if (velocidade < 0) velocidade = 0;
        System.out.println("Carro freou para " + velocidade + " km/h");
    }

    @Override
    public void abastecer() {
        System.out.println("Abastecendo carro com gasolina");
    }
}
