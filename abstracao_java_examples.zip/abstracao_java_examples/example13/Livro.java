public class Livro extends Produto {
    public Livro(String nome, double preco) {
        super(nome, preco);
    }

    @Override
    public void aplicarDesconto() {
        preco *= 0.8; // 20% de desconto
        System.out.println("Desconto de livro aplicado");
    }
}
