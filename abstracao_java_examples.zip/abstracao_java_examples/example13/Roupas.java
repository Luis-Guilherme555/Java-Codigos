public class Roupas extends Produto {
    public Roupas(String nome, double preco) {
        super(nome, preco);
    }

    @Override
    public void aplicarDesconto() {
        preco *= 0.7; // 30% de desconto
        System.out.println("Desconto de roupa aplicado");
    }
}
