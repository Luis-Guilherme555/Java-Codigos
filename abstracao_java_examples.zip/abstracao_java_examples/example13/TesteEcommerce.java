import java.util.ArrayList;
import java.util.List;

public class TesteEcommerce {
    public static void main(String[] args) {
        List<Produto> produtos = new ArrayList<>();
        produtos.add(new Livro("Java Básico", 50));
        produtos.add(new Eletronico("Smartphone", 1000));
        produtos.add(new Roupas("Camiseta", 30));

        for (Produto produto : produtos) {
            produto.mostrarPreco();
            produto.aplicarDesconto();
            produto.mostrarPreco();
            System.out.println("---");
        }
    }
}
