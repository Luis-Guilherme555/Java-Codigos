public class Eletronico extends Produto {
    public Eletronico(String nome, double preco) {
        super(nome, preco);
    }

    @Override
    public void aplicarDesconto() {
        preco *= 0.9; // 10% de desconto
        System.out.println("Desconto de eletrônico aplicado");
    }
}
