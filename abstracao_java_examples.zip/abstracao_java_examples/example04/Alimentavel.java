public interface Alimentavel {
    void comer();
}
