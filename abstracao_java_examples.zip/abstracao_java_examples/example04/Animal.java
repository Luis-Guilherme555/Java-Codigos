public abstract class Animal implements Alimentavel {
    public abstract void emitirSom();

    public void dormir() {
        System.out.println("Zzzzz...");
    }
}
