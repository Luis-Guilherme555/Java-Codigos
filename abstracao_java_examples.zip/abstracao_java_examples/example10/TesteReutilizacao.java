public class TesteReutilizacao {
    public static void main(String[] args) {
        ContaCorrente cc = new ContaCorrente();
        cc.depositar(500);
        cc.consultarSaldo(); // Herdado da classe abstrata
    }
}
