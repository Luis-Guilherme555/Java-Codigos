public abstract class ContaBancaria {
    protected double saldo;

    // Método concreto - reutilizado por todas as subclasses
    public void consultarSaldo() {
        System.out.println("Saldo atual: R$" + saldo);
    }

    public abstract void sacar(double valor);
    public abstract void depositar(double valor);
}
