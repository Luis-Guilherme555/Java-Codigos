public class Guerreiro extends Personagem {
    public Guerreiro(String nome) {
        super(nome, 100);
    }

    @Override
    public void atacar() {
        System.out.println(nome + " ataca com espada!");
    }
}
