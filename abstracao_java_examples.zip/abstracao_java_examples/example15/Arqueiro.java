public class Arqueiro extends Personagem implements Especial {
    public Arqueiro(String nome) {
        super(nome, 70);
    }

    @Override
    public void atacar() {
        System.out.println(nome + " dispara uma flecha precisa!");
    }

    @Override
    public void usarHabilidade() {
        System.out.println(nome + " usa flecha múltipla!");
    }
}
