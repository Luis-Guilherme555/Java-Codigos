public interface Especial {
    void usarHabilidade();
}
