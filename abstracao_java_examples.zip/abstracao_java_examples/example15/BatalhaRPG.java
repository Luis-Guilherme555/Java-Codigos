import java.util.ArrayList;
import java.util.List;

public class BatalhaRPG {
    public static void main(String[] args) {
        List<Personagem> personagens = new ArrayList<>();
        personagens.add(new Guerreiro("Conan"));
        personagens.add(new Mago("Gandalf"));
        personagens.add(new Arqueiro("Legolas"));

        System.out.println("=== INÍCIO DA BATALHA ===");

        for (Personagem personagem : personagens) {
            System.out.println("\nTurno de " + personagem.getNome() + ":");
            personagem.atacar(); // Polimorfismo básico

            // Verifica se tem habilidade especial
            if (personagem instanceof Especial) {
                Especial especial = (Especial) personagem;
                especial.usarHabilidade(); // Polimorfismo da interface
            }

            personagem.receberDano(10); // Método concreto da classe abstrata
        }

        System.out.println("\n=== FIM DA BATALHA ===");
    }
}
