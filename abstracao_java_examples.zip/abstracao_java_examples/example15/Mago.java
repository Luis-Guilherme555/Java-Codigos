public class Mago extends Personagem implements Especial {
    public Mago(String nome) {
        super(nome, 80);
    }

    @Override
    public void atacar() {
        System.out.println(nome + " lança uma bola de fogo!");
    }

    @Override
    public void usarHabilidade() {
        System.out.println(nome + " usa cura mágica!");
    }
}
