// Animal.java
public abstract class Animal {
    public abstract void emitirSom();
}
