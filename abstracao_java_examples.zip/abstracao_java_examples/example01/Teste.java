// Teste.java
public class Teste {
    public static void main(String[] args) {
        Animal cachorro = new Cachorro();
        Animal gato = new Gato();

        cachorro.emitirSom(); // Au au!
        gato.emitirSom();     // Miau!
    }
}
