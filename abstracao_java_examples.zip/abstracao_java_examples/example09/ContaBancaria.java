public abstract class ContaBancaria {
    protected double saldo;

    public ContaBancaria() {
        this.saldo = 0;
    }

    public abstract void sacar(double valor);
    public abstract void depositar(double valor);
}
