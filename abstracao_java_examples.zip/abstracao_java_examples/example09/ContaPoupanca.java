public class ContaPoupanca extends ContaBancaria {
    @Override
    public void depositar(double valor) {
        saldo += valor;
        System.out.println("Depositado R$" + valor + " na poupança");
    }

    @Override
    public void sacar(double valor) {
        if (saldo >= valor) {
            saldo -= valor;
            System.out.println("Sacado R$" + valor + " da poupança");
        } else {
            System.out.println("Saldo insuficiente");
        }
    }
}
