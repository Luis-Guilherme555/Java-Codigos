public class ContaCorrente extends ContaBancaria {
    private static final double TAXA_SAQUE = 1.50;

    @Override
    public void depositar(double valor) {
        saldo += valor;
        System.out.println("Depositado R$" + valor + " na conta corrente");
    }

    @Override
    public void sacar(double valor) {
        double total = valor + TAXA_SAQUE;
        if (saldo >= total) {
            saldo -= total;
            System.out.println("Sacado R$" + valor + " (taxa: R$" + TAXA_SAQUE + ")");
        } else {
            System.out.println("Saldo insuficiente");
        }
    }
}
