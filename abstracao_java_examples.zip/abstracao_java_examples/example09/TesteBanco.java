import java.util.ArrayList;
import java.util.List;

public class TesteBanco {
    public static void main(String[] args) {
        List<ContaBancaria> contas = new ArrayList<>();
        contas.add(new ContaCorrente());
        contas.add(new ContaPoupanca());

        for (ContaBancaria conta : contas) {
            conta.depositar(1000);
            conta.sacar(100);
            System.out.println("---");
        }
    }
}
