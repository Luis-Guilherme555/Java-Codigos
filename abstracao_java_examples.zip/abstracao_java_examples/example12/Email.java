public class Email implements Notificacao {
    @Override
    public void enviar(String msg) {
        System.out.println("Enviando email: " + msg);
    }
}
