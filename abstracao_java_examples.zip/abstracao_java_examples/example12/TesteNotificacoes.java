import java.util.ArrayList;
import java.util.List;

public class TesteNotificacoes {
    public static void main(String[] args) {
        List<Notificacao> notificacoes = new ArrayList<>();
        notificacoes.add(new Email());
        notificacoes.add(new SMS());
        notificacoes.add(new PushNotification());

        String mensagem = "Promoção especial!";
        for (Notificacao notificacao : notificacoes) {
            notificacao.enviar(mensagem);
        }
    }
}
