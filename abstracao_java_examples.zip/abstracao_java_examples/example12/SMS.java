public class SMS implements Notificacao {
    @Override
    public void enviar(String msg) {
        System.out.println("Enviando SMS: " + msg);
    }
}
