public class PushNotification implements Notificacao {
    @Override
    public void enviar(String msg) {
        System.out.println("Enviando push: " + msg);
    }
}
