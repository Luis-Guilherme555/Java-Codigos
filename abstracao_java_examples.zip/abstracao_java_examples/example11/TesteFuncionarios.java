import java.util.ArrayList;
import java.util.List;

public class TesteFuncionarios {
    public static void main(String[] args) {
        List<Funcionario> funcionarios = new ArrayList<>();
        funcionarios.add(new Gerente("João", 5000, 1000));
        funcionarios.add(new Vendedor("Maria", 2000, 500));

        for (Funcionario func : funcionarios) {
            System.out.println(func.getNome() + ": R$" + func.calcularSalario());
        }
    }
}
