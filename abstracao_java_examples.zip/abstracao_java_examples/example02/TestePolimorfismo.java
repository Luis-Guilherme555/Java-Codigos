public class TestePolimorfismo {
    public static void main(String[] args) {
        Animal[] animais = new Animal[3];
        animais[0] = new Cachorro();
        animais[1] = new Gato();
        animais[2] = new Cachorro();

        for (Animal animal : animais) {
            animal.emitirSom(); // Cada animal emite seu som específico
        }
    }
}
