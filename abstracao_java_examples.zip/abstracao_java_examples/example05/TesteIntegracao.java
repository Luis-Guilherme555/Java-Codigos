import java.util.ArrayList;
import java.util.List;

public class TesteIntegracao {
    public static void main(String[] args) {
        List<Animal> animais = new ArrayList<>();
        animais.add(new Cachorro());
        animais.add(new Gato());
        animais.add(new Cachorro());

        for (Animal animal : animais) {
            animal.emitirSom(); // Polimorfismo
            animal.dormir();    // Herança do método concreto
            animal.comer();     // Polimorfismo da interface
            System.out.println("---");
        }
    }
}
