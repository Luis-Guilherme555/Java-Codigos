package questao03;

public class AutomovelAVenda extends VeiculoAVenda{
    
    public AutomovelAVenda(int ano, double precoDeVenda) {
        super( ano, precoDeVenda);
        this.tipo="automovel";
    }
    
    @Override
    public String exibirDetalhes(){
        return "Este e um " +tipo+ " do Ano: " +ano+  " Pelo Preco: " +precoDeVenda+ " disponivel para compra.";
    }
}
