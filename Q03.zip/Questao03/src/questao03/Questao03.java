package questao03;

import java.util.ArrayList;
import java.util.List;

public class Questao03 {

    public static void main(String[] args) { 
        
        AutomovelAVenda A1 = new AutomovelAVenda( 2010, 3500.0);
        AutomovelAVenda A2 = new AutomovelAVenda( 2015, 7500.0);
        
        MotocicletaAVenda M1 = new MotocicletaAVenda( 2012, 2450.0);
        MotocicletaAVenda M2 = new MotocicletaAVenda( 2017, 4500.0);
        
        List<VeiculoAVenda> V1  = new ArrayList<>();
        
        V1.add(new AutomovelAVenda (2010, 3500.0));
        V1.add(new AutomovelAVenda (2015, 7500.0));
        V1.add(new MotocicletaAVenda( 2012, 2450.0));
        V1.add(new MotocicletaAVenda( 2017, 4500.0));
        
        for(VeiculoAVenda VeiculosAVenda : V1){
            System.out.println("Detalhes: " +VeiculosAVenda.exibirDetalhes());
        }
    }
    
}
