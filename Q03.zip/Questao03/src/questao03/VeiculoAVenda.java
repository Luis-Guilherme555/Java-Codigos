package questao03;

public class VeiculoAVenda {
    public String tipo;
    public int ano;
    public double precoDeVenda;
    
    public VeiculoAVenda( int ano, double precoDeVenda){
        this.ano=ano;
        this.precoDeVenda=precoDeVenda;
    }
    
    public String tipo(){
        return tipo;
    }
    
    public String exibirDetalhes(){
        return "Tipo: " +tipo+ " Ano: " +ano+ " Preco: R$" +precoDeVenda;
    }
}
