package questao03;

public class MotocicletaAVenda extends VeiculoAVenda{
    
    public MotocicletaAVenda( int ano, double precoDeVenda) {
        super( ano, precoDeVenda);
        this.tipo="Motocicleta";
    }
    
    @Override
    public String exibirDetalhes(){
        return "Esta e uma " +tipo+ " do Ano: " +ano+  " Pelo Preco: " +precoDeVenda+ " disponivel para compra.";
    }
    
}
