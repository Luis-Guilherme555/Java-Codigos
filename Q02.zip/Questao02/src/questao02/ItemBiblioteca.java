package questao02;

abstract class ItemBiblioteca {
    private String titulo;
    private String codigo;
    private boolean emprestado;
    
    public ItemBiblioteca(String titulo, String codigo, boolean emprestado){
        this.titulo=titulo;
        this.codigo=codigo;
        this.emprestado=false;
    }
    
    public abstract double MultaAtraso(int diasAtraso);
    
    public boolean emprestar(){
        if(emprestado = false){
            return false;
        }else{
            return true;
        }
    }
    
    public String getTitulo(){
        return titulo;
    }
    
    public String getCodigo(){
        return codigo;
    }
    
    public boolean Devolver(){
        return emprestado;
    }
    
    public boolean emprestado(){
        return emprestado;
    }
    
    public boolean isEmprestado(){
        return emprestado;
    }
}
