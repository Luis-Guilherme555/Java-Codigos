package questao02;

import java.util.ArrayList;
import java.util.List;

public class Questao02 {

    public static void main(String[] args) {
        
        List<ItemBiblioteca> IB = new ArrayList<>();
        
        IB.add(new Livro("Pequeno Principe ", "1924", false, "Joelson"));
        IB.add(new Livro("O Cavaleiro das Trevas ", "1875", false, "Miller"));
        IB.add(new Revista("O Reino do Amanhã ", "1874", false, 2));
        IB.add(new Revista("A Arte da Guerra ", "1950", false, 1));
        
    }
    
}
