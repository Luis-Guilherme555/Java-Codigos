package questao02;

public class Livro extends ItemBiblioteca{
    private String autor;

    public Livro(String titulo, String codigo, boolean emprestado, String autor) {
        super(titulo, codigo, emprestado);
        this.autor=autor;
    }

    @Override
    public double MultaAtraso(int diasAtraso) {
        return diasAtraso * 2.0;
    }
    
    public String getAutor(){
        return autor;
    }
    
}
