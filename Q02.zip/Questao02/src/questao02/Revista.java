package questao02;

public class Revista extends ItemBiblioteca{
    private int edicao;
    
    public Revista(String titulo, String codigo, boolean emprestado, int edicao) {
        super(titulo, codigo, emprestado);
        this.edicao=edicao;
    }

    @Override
    public double MultaAtraso(int diasAtraso) {
         return diasAtraso * 1.0;
    }
    
    public int getEdicao(){
        return edicao;
    }
    
}
